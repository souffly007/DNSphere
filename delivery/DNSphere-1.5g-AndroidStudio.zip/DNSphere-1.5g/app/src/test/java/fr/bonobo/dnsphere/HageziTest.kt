package fr.bonobo.dnsphere

import fr.bonobo.dnsphere.data.ProviderMigration
import fr.bonobo.dnsphere.data.DnsProviderCatalog
import fr.bonobo.dnsphere.dns.DohResponsePolicy
import org.junit.Assert.*
import org.junit.Test

class HageziTest {
    @Test fun onlyKnownStandardQuad9IsMigrated() {
        assertEquals("hagezi-security", ProviderMigration.normalize(" Quad9 "))
        assertEquals("hagezi-security", ProviderMigration.normalize("https://dns.quad9.net/dns-query"))
        assertEquals("quad9-unfiltered", ProviderMigration.normalize("quad9-unfiltered"))
        for (id in listOf("mullvad", "dns4eu-child", "hagezi-full", "standard")) {
            assertEquals(id, ProviderMigration.normalize(id))
        }
        assertFalse(DnsProviderCatalog.ids.contains("quad9"))
        assertTrue(DnsProviderCatalog.ids.containsAll(listOf("hagezi-security", "hagezi-full")))
    }

    private val query = byteArrayOf(0x12, 0x34, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0,
        1, 97, 0, 0, 1, 0, 1)
    private fun answer(rcode: Int) = query.copyOf().also {
        it[2] = 0x81.toByte(); it[3] = (0x80 or rcode).toByte()
    }
    @Test fun normalFilteringAnswersDoNotCauseFailover() {
        for (rcode in listOf(0, 3, 5)) assertTrue(DohResponsePolicy.isUsable(query, answer(rcode)))
    }
    @Test fun serviceFailureAndMalformedAnswersCauseFailover() {
        assertFalse(DohResponsePolicy.isUsable(query, answer(2)))
        assertFalse(DohResponsePolicy.isUsable(query, byteArrayOf(1, 2)))
        assertFalse(DohResponsePolicy.isUsable(query, answer(0).also { it[0] = 99 }))
        assertFalse(DohResponsePolicy.isUsable(query, answer(0).also { it[13] = 98 }))
        assertFalse(DohResponsePolicy.isUsable(query, query))
    }
    @Test fun aaaaQuestionsAreAccepted() {
        val aaaa = query.copyOf().also { it[16] = 28 }
        val response = aaaa.copyOf().also { it[2] = 0x81.toByte() }
        assertTrue(DohResponsePolicy.isUsable(aaaa, response))
    }
}

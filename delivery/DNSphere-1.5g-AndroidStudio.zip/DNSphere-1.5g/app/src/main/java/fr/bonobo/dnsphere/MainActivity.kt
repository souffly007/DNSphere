package fr.bonobo.dnsphere

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.switchmaterial.SwitchMaterial
import fr.bonobo.dnsphere.data.AppDatabase
import fr.bonobo.dnsphere.data.DnsProviderCatalog
import fr.bonobo.dnsphere.security.BiometricHelper
import fr.bonobo.dnsphere.security.ProtectedAction
import fr.bonobo.dnsphere.ui.*
import fr.bonobo.dnsphere.utils.PowerUtils
import fr.bonobo.dnsphere.widget.DnsphereWidget

class MainActivity : AppCompatActivity() {

    companion object {
        const val GITHUB_URL     = "https://github.com/souffly007/DNSphere"
        const val DEVELOPER_URL  = "https://github.com/souffly007"
        const val DEVELOPER_NAME = "souffly007"
    }

    private lateinit var btnToggle: MaterialButton
    private lateinit var tvStatus: TextView
    private lateinit var tvCurrentDns: TextView
    private lateinit var tvAdsBlocked: TextView
    private lateinit var tvTrackersBlocked: TextView
    private lateinit var tvTotalBlocked: TextView
    private lateinit var tvOtherBlocked: TextView
    private lateinit var tvCreatedBy: TextView
    private lateinit var switchAds: SwitchMaterial
    private lateinit var switchTrackers: SwitchMaterial
    private lateinit var switchMalware: SwitchMaterial

    private lateinit var database: AppDatabase
    private lateinit var biometricHelper: BiometricHelper
    private var isVpnRunning = false

    // =========================================================================
    // Observer permanent — non lié au lifecycle de l'activité
    // Permet de recevoir les updates même quand l'activité est en STARTED
    // (écran allumé mais app en arrière-plan ne pose pas de problème car
    // observeForever reçoit toujours, et on le retire dans onDestroy)
    // =========================================================================
    private val statsObserver = Observer<VpnStats> { stats ->
        tvAdsBlocked.text      = stats.adsBlocked.toString()
        tvTrackersBlocked.text = stats.trackersBlocked.toString()
        updateTotalStats(stats)
        saveStatsForWidget(stats)
        Log.d("MainActivity", "📊 Stats reçues: Pubs=${stats.adsBlocked}, Trackers=${stats.trackersBlocked}")
    }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startVpnService()
        } else {
            Toast.makeText(this, R.string.vpn_permission_denied, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val migration = getSharedPreferences("provider_migration", MODE_PRIVATE)
        if (migration.getBoolean("notice_pending", false)) {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setMessage(if (migration.getInt("replaced_references", 0) > 1)
                    "Vos choix Quad9 enregistrés ont été remplacés par HaGeZi Sécurité."
                    else "Votre profil Quad9 a été remplacé par HaGeZi Sécurité.")
                .setPositiveButton(android.R.string.ok) { _, _ ->
                    migration.edit().putBoolean("notice_pending", false).commit()
                }.setCancelable(false).show()
        }

        supportActionBar?.hide()

        database        = AppDatabase.getInstance(this)
        biometricHelper = BiometricHelper.getInstance(this)

        initViews()
        setupListeners()
        loadPreferences()
        loadCurrentStats()
        updateCurrentDnsLabel()

        // observeForever : reçoit les updates quel que soit l'état du lifecycle
        StatsLiveData.vpnStats.observeForever(statsObserver)

        // Démarrage du watchdog — surveille le VPN toutes les 15 min
        WatchdogWorker.start(this)

        if (intent.getBooleanExtra("auto_start", false) && !LocalVpnService.isRunning) {
            requestVpnPermission()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun initViews() {
        btnToggle         = findViewById(R.id.btnToggle)
        tvStatus          = findViewById(R.id.tvStatus)
        tvCurrentDns      = findViewById(R.id.tvCurrentDns)
        tvAdsBlocked      = findViewById(R.id.tvAdsBlocked)
        tvTrackersBlocked = findViewById(R.id.tvTrackersBlocked)
        tvTotalBlocked    = findViewById(R.id.tvTotalBlocked)
        tvOtherBlocked    = findViewById(R.id.tvOtherBlocked)
        tvCreatedBy       = findViewById(R.id.tvCreatedBy)
        switchAds         = findViewById(R.id.switchAds)
        switchTrackers    = findViewById(R.id.switchTrackers)
        switchMalware     = findViewById(R.id.switchMalware)

        tvCreatedBy.text = getString(R.string.created_by, DEVELOPER_NAME)
    }

    private fun setupListeners() {
        btnToggle.setOnClickListener {
            if (isVpnRunning) stopVpnService() else requestVpnPermission()
        }

        switchAds.setOnCheckedChangeListener { _, isChecked ->
            savePreference("block_ads", isChecked)
            updateServiceConfig()
        }

        switchTrackers.setOnCheckedChangeListener { _, isChecked ->
            savePreference("block_trackers", isChecked)
            updateServiceConfig()
        }

        switchMalware.setOnCheckedChangeListener { _, isChecked ->
            savePreference("block_malware", isChecked)
            updateServiceConfig()
        }

        findViewById<View>(R.id.cardStats).setOnClickListener {
            startActivity(Intent(this, LogsActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnLogs).setOnClickListener {
            startActivity(Intent(this, LogsActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnWhitelist).setOnClickListener {
            startActivity(Intent(this, WhitelistActivity::class.java))
        }

        findViewById<MaterialButton>(R.id.btnSettings).setOnClickListener {
            openSettings()
        }

        findViewById<MaterialButton>(R.id.btnApps).setOnClickListener {
            startActivity(Intent(this, AppsActivity::class.java))
        }

        findViewById<TextView>(R.id.tvGitHub)?.setOnClickListener {
            openUrl(GITHUB_URL)
        }

        tvCreatedBy.setOnClickListener {
            openUrl(DEVELOPER_URL)
        }
    }

    private fun openSettings() {
        if (biometricHelper.isAuthRequired(ProtectedAction.ACCESS_SETTINGS)) {
            biometricHelper.authenticateForAction(
                activity  = this,
                action    = ProtectedAction.ACCESS_SETTINGS,
                onSuccess = { startActivity(Intent(this, SettingsActivity::class.java)) },
                onCancel  = { }
            )
        } else {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.cannot_open_link, Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermissionLauncher.launch(intent)
        else startVpnService()
    }

    private fun startVpnService() {
        val prefs    = getSharedPreferences("vpn_prefs", MODE_PRIVATE)
        val dnsPrefs = getSharedPreferences("dnsphere_prefs", MODE_PRIVATE)

        val intent = Intent(this, LocalVpnService::class.java).apply {
            action = LocalVpnService.ACTION_START
            putExtra("block_ads",      prefs.getBoolean("block_ads",      true))
            putExtra("block_trackers", prefs.getBoolean("block_trackers", true))
            putExtra("block_malware",  prefs.getBoolean("block_malware",  true))
            putExtra("block_social",   prefs.getBoolean("block_social",   false))
            putExtra("block_adult",    prefs.getBoolean("block_adult",    false))
            putExtra("block_gambling", prefs.getBoolean("block_gambling", false))
            putExtra("use_doh",        dnsPrefs.getBoolean("use_doh",     false))
            putExtra("use_dot",        dnsPrefs.getBoolean("use_dot",     false))
            putExtra("use_doq",        dnsPrefs.getBoolean("use_doq",     false))
            putExtra("use_doh3",       dnsPrefs.getBoolean("use_doh3",    false))
            putExtra("doh_provider",   dnsPrefs.getString("current_dns_provider", "cloudflare"))
        }

        ContextCompat.startForegroundService(this, intent)
        setVpnShouldRun(true)
        updateUI(true)
        DnsphereWidget.updateWidget(this)
        Toast.makeText(this, R.string.protection_started, Toast.LENGTH_SHORT).show()
    }

    private fun stopVpnService() {
        if (biometricHelper.isAuthRequired(ProtectedAction.DISABLE_VPN)) {
            biometricHelper.authenticateForAction(
                activity  = this,
                action    = ProtectedAction.DISABLE_VPN,
                onSuccess = { doStopVpnService() },
                onCancel  = { }
            )
        } else {
            doStopVpnService()
        }
    }

    private fun doStopVpnService() {
        val intent = Intent(this, LocalVpnService::class.java).apply {
            action = LocalVpnService.ACTION_STOP
        }
        startService(intent)
        setVpnShouldRun(false)
        updateUI(false)
        DnsphereWidget.updateWidget(this)
        Toast.makeText(this, R.string.protection_stopped, Toast.LENGTH_SHORT).show()
    }

    private fun setVpnShouldRun(shouldRun: Boolean) {
        getSharedPreferences("dnsphere_prefs", MODE_PRIVATE)
            .edit()
            .putBoolean("vpn_should_be_running", shouldRun)
            .apply()
    }

    private fun updateUI(running: Boolean) {
        isVpnRunning = running
        if (running) {
            btnToggle.text = getString(R.string.status_on)
            btnToggle.backgroundTintList = ColorStateList.valueOf(getColor(R.color.green))
            tvStatus.text = getString(R.string.protection_enabled)
            tvStatus.setTextColor(getColor(R.color.green))
        } else {
            btnToggle.text = getString(R.string.status_off)
            btnToggle.backgroundTintList = ColorStateList.valueOf(getColor(R.color.red))
            tvStatus.text = getString(R.string.protection_disabled)
            tvStatus.setTextColor(getColor(R.color.gray))
        }
    }

    private fun updateServiceConfig() {
        if (!isVpnRunning) return
        val prefs    = getSharedPreferences("vpn_prefs", MODE_PRIVATE)
        val dnsPrefs = getSharedPreferences("dnsphere_prefs", MODE_PRIVATE)
        val intent   = Intent(this, LocalVpnService::class.java).apply {
            action = LocalVpnService.ACTION_UPDATE_CONFIG
            putExtra("block_ads",      prefs.getBoolean("block_ads",      true))
            putExtra("block_trackers", prefs.getBoolean("block_trackers", true))
            putExtra("block_malware",  prefs.getBoolean("block_malware",  true))
            putExtra("block_social",   prefs.getBoolean("block_social",   false))
            putExtra("block_adult",    prefs.getBoolean("block_adult",    false))
            putExtra("block_gambling", prefs.getBoolean("block_gambling", false))
            putExtra("use_doh",        dnsPrefs.getBoolean("use_doh",     false))
            putExtra("use_dot",        dnsPrefs.getBoolean("use_dot",     false))
            putExtra("use_doq",        dnsPrefs.getBoolean("use_doq",     false))
            putExtra("use_doh3",       dnsPrefs.getBoolean("use_doh3",    false))
            putExtra("doh_provider",   dnsPrefs.getString("current_dns_provider", "cloudflare"))
        }
        startService(intent)
    }

    private fun savePreference(key: String, value: Boolean) {
        getSharedPreferences("vpn_prefs", MODE_PRIVATE).edit().putBoolean(key, value).apply()
    }

    private fun loadPreferences() {
        val prefs = getSharedPreferences("vpn_prefs", MODE_PRIVATE)
        switchAds.isChecked      = prefs.getBoolean("block_ads",      true)
        switchTrackers.isChecked = prefs.getBoolean("block_trackers", true)
        switchMalware.isChecked  = prefs.getBoolean("block_malware",  true)
    }

    private fun updateCurrentDnsLabel() {
        val prefs = getSharedPreferences("dnsphere_prefs", MODE_PRIVATE)
        val provider = prefs.getString("current_dns_provider", "standard") ?: "standard"
        val label = getDnsDisplayName(provider)
        tvCurrentDns.text = if (isVpnRunning && provider.startsWith("hagezi-"))
            "$label — ${fr.bonobo.dnsphere.dns.DohResolver.getInstance(this).transportStatus}"
        else label
    }

    private fun getDnsDisplayName(provider: String): String =
        if (provider.equals("off", ignoreCase = true)) {
            DnsProviderCatalog.labelFor("standard")
        } else {
            DnsProviderCatalog.labelFor(provider)
        }

    private fun loadCurrentStats() {
        val prefs           = getSharedPreferences("dnsphere_stats", MODE_PRIVATE)
        val adsBlocked      = prefs.getInt("ads_blocked", 0)
        val trackersBlocked = prefs.getInt("trackers_blocked", 0)
        val malwareBlocked  = prefs.getInt("malware_blocked", 0)
        val shoppingBlocked = prefs.getInt("shopping_blocked", 0)
        val otherBlocked    = prefs.getInt("other_blocked", 0)
        tvAdsBlocked.text      = adsBlocked.toString()
        tvTrackersBlocked.text = trackersBlocked.toString()
        updateTotalStats(
            VpnStats(
                adsBlocked = adsBlocked,
                trackersBlocked = trackersBlocked,
                malwareBlocked = malwareBlocked,
                shoppingBlocked = shoppingBlocked,
                otherBlocked = otherBlocked
            )
        )
        Log.d("MainActivity", "📊 Stats chargées: Pubs=$adsBlocked, Trackers=$trackersBlocked")
    }

    private fun updateTotalStats(stats: VpnStats) {
        val total = stats.adsBlocked + stats.trackersBlocked + stats.malwareBlocked +
                stats.shoppingBlocked + stats.otherBlocked
        val other = stats.malwareBlocked + stats.shoppingBlocked + stats.otherBlocked
        tvTotalBlocked.text = getString(R.string.main_total_blocked, total)
        tvOtherBlocked.text = getString(R.string.main_other_blocked, other)
    }

    private fun saveStatsForWidget(stats: VpnStats) {
        getSharedPreferences("dnsphere_stats", MODE_PRIVATE).edit()
            .putInt("ads_blocked", stats.adsBlocked)
            .putInt("trackers_blocked", stats.trackersBlocked)
            .putInt("malware_blocked", stats.malwareBlocked)
            .putInt("shopping_blocked", stats.shoppingBlocked)
            .putInt("other_blocked", stats.otherBlocked)
            .apply()
    }

    override fun onResume() {
        super.onResume()
        loadCurrentStats()
        isVpnRunning = LocalVpnService.isRunning
        updateUI(isVpnRunning)
        loadPreferences()
        updateCurrentDnsLabel()
        checkMiuiRestrictions()
    }

    // =========================================================================
    // MIUI / HyperOS — détection des restrictions batterie/autostart
    // =========================================================================
    // Sur MIUI/HyperOS, le système peut tuer DNSphere en arrière-plan (ex: à
    // l'ouverture de l'appareil photo) même si la protection est active, tant
    // que l'app n'est pas dans les exceptions "Autostart" / "Sans restriction
    // batterie". On avertit au premier lancement (onboarding) ET à chaque
    // retour sur l'app tant que ce n'est pas réglé (détection runtime).
    // =========================================================================

    private fun checkMiuiRestrictions() {
        if (!PowerUtils.isMiuiOrHyperOs()) return
        if (PowerUtils.isIgnoringBatteryOptimizations(this)) return

        val prefs = getSharedPreferences("dnsphere_prefs", MODE_PRIVATE)
        if (prefs.getBoolean("miui_warning_dismissed", false)) return

        showMiuiRestrictionDialog()
    }

    private fun showMiuiRestrictionDialog() {
        val romName = if (PowerUtils.isHyperOs()) "HyperOS" else "MIUI"

        MaterialAlertDialogBuilder(this)
            .setTitle("⚠️ Sécuriser la protection ($romName)")
            .setMessage(
                "Sur $romName, le système peut arrêter DNSphere en arrière-plan " +
                        "(par exemple à l'ouverture de l'appareil photo), même quand la " +
                        "protection est censée être active.\n\n" +
                        "Pour l'éviter, deux réglages sont recommandés :\n" +
                        "1. Autoriser le démarrage automatique\n" +
                        "2. Désactiver l'optimisation de la batterie pour DNSphere"
            )
            .setPositiveButton("Batterie") { _, _ ->
                PowerUtils.requestIgnoreBatteryOptimizations(this)
            }
            .setNeutralButton("Autostart") { _, _ ->
                PowerUtils.openMiuiAutostartSettings(this)
            }
            .setNegativeButton("Ne plus afficher") { _, _ ->
                getSharedPreferences("dnsphere_prefs", MODE_PRIVATE).edit()
                    .putBoolean("miui_warning_dismissed", true)
                    .apply()
            }
            .setCancelable(true)
            .show()
    }

    // =========================================================================
    // IMPORTANT : retirer l'observer permanent pour éviter les memory leaks
    // =========================================================================
    override fun onDestroy() {
        super.onDestroy()
        StatsLiveData.vpnStats.removeObserver(statsObserver)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.let {
            if (it.getBooleanExtra("auto_start", false) && !LocalVpnService.isRunning) {
                requestVpnPermission()
            }
        }
    }
}

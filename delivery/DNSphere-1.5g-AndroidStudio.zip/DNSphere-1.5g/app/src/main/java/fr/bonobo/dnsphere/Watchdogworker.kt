// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2025-2026 Franck R-F (souffly007)
// This file is part of PhoneZen.
//
// PhoneZen is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License.
package fr.bonobo.dnsphere

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.work.*
import fr.bonobo.dnsphere.data.AppDatabase
import fr.bonobo.dnsphere.data.LogRetentionPolicy
import kotlinx.coroutines.runBlocking
import java.util.concurrent.TimeUnit

/**
 * Watchdog VPN — vérifie toutes les 15 minutes que le service est actif.
 * Si le VPN est mort et que l'utilisateur l'avait activé, il le relance automatiquement.
 */
class WatchdogWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    companion object {
        private const val TAG       = "WatchdogWorker"
        private const val WORK_NAME = "dnsphere_watchdog"

        /**
         * Démarre le watchdog en mode périodique.
         * À appeler une fois au démarrage de l'app (dans MainActivity.onCreate).
         */
        fun start(context: Context) {
            val request = PeriodicWorkRequestBuilder<WatchdogWorker>(15, TimeUnit.MINUTES)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                        .build()
                )
                .setBackoffCriteria(BackoffPolicy.LINEAR, 5, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP, // Ne pas remplacer si déjà en cours
                request
            )

            Log.d(TAG, "✅ Watchdog démarré (période: 15 min)")
        }

        /**
         * Arrête le watchdog (si l'utilisateur désactive définitivement la protection).
         */
        fun stop(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
            Log.d(TAG, "🛑 Watchdog arrêté")
        }

        /**
         * Déclenche une vérification/relance ponctuelle quasi immédiate, sans attendre
         * le prochain cycle périodique (jusqu'à 15 min). Appelé par LocalVpnService
         * lors d'un arrêt inattendu (onRevoke, tunnel mort) pour réduire au minimum
         * la fenêtre pendant laquelle la protection reste coupée.
         */
        fun runOnceNow(context: Context, delaySeconds: Long = 5) {
            val request = OneTimeWorkRequestBuilder<WatchdogWorker>()
                .setInitialDelay(delaySeconds, TimeUnit.SECONDS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueue(request)
            Log.d(TAG, "⚡ Relance immédiate programmée (+${delaySeconds}s)")
        }
    }

    override fun doWork(): Result {
        Log.d(TAG, "🔍 Vérification VPN...")

        // Les paramètres de l'écran SettingsActivity sont stockés dans vpn_prefs.
        val prefs      = context.getSharedPreferences("vpn_prefs", Context.MODE_PRIVATE)
        val userWantsVpn = prefs.getBoolean("vpn_should_be_running", false)

        // Purge quotidienne des journaux détaillés selon la politique commune.
        try {
            val lastPurge = prefs.getLong("last_stats_purge", 0L)
            val now       = System.currentTimeMillis()
            if (now - lastPurge > 24 * 60 * 60 * 1000L) {
                val retentionDays = LogRetentionPolicy.normalizeDays(
                    prefs.getLong(
                        "stats_retention_days",
                        LogRetentionPolicy.DEFAULT_RETENTION_DAYS
                    )
                )
                val cutoff = LogRetentionPolicy.cutoff(now, retentionDays)

                // Obtenir le DAO depuis la base de données Room
                val deleted = runBlocking {
                    val database = AppDatabase.getInstance(context)
                    val dao = database.blockLogDao()
                    val count = dao.countOldLogs(cutoff)
                    dao.deleteOldLogs(cutoff)
                    count
                }

                prefs.edit().putLong("last_stats_purge", now).apply()
                Log.d(TAG, "🗑️ $deleted logs purgés — rétention: $retentionDays jours")
            }
        } catch (e: Exception) {
            Log.e(TAG, "❌ Erreur lors de la purge des stats: ${e.message}", e)
            // On continue l'exécution même si la purge échoue
        }

        if (!userWantsVpn) {
            Log.d(TAG, "ℹ️ VPN désactivé par l'utilisateur, pas de relance")
            return Result.success()
        }

        if (LocalVpnService.isRunning) {
            Log.d(TAG, "✅ VPN actif, rien à faire")
            return Result.success()
        }

        // VPN mort alors que l'utilisateur l'avait activé → relance
        Log.w(TAG, "⚠️ VPN inactif détecté ! Relance en cours...")

        return try {
            val vpnPrefs = context.getSharedPreferences("vpn_prefs", Context.MODE_PRIVATE)
            val dnsPrefs = context.getSharedPreferences("dnsphere_prefs", Context.MODE_PRIVATE)

            val intent = Intent(context, LocalVpnService::class.java).apply {
                action = LocalVpnService.ACTION_START
                putExtra("block_ads",      vpnPrefs.getBoolean("block_ads",      true))
                putExtra("block_trackers", vpnPrefs.getBoolean("block_trackers", true))
                putExtra("block_malware",  vpnPrefs.getBoolean("block_malware",  true))
                putExtra("block_social",   vpnPrefs.getBoolean("block_social",   false))
                putExtra("block_adult",    vpnPrefs.getBoolean("block_adult",    false))
                putExtra("block_gambling", vpnPrefs.getBoolean("block_gambling", false))
                putExtra("use_doh",        dnsPrefs.getBoolean("use_doh",        false))
                putExtra("use_dot",        dnsPrefs.getBoolean("use_dot",        false))
                putExtra("use_doq",        dnsPrefs.getBoolean("use_doq",        false))
                putExtra("use_doh3",       dnsPrefs.getBoolean("use_doh3",       false))
                putExtra("doh_provider",   dnsPrefs.getString("current_dns_provider", "cloudflare"))
            }

            ContextCompat.startForegroundService(context, intent)
            Log.d(TAG, "✅ VPN relancé par le watchdog")
            Result.success()

        } catch (e: Exception) {
            Log.e(TAG, "❌ Echec relance VPN: ${e.message}")
            Result.retry()
        }
    }
}

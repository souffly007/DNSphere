package fr.bonobo.dnsphere.data

/** Only the standard, filtered Quad9 identifier existed in the released catalog. */
object ProviderMigration {
    fun normalize(value: String): String = when (value.lowercase().trim()) {
        "quad9", "https://dns.quad9.net/dns-query", "https://dns.quad9.net:5053/dns-query" -> "hagezi-security"
        else -> value.lowercase().trim()
    }
}
